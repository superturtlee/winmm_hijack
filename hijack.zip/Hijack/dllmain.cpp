﻿#include "pch.h"
//实用工具，用于HOOK XBOX API,仅供学习研究()使用
#include <Windows.h>
#include <iostream>
#include <MinHook.h>
#include "XStoreAPIHooks.h"
#pragma comment(lib, "libMinHook.x64.lib")

// Function pointer type for QueryApiImpl
typedef __int64(__fastcall* QueryApiImpl_t)(GUID* a1, GUID* a2, void* a3);

// Pointer to the original function
QueryApiImpl_t pOriginalQueryApiImpl = nullptr;

// Hooked function
__int64 __fastcall HookedQueryApiImpl(GUID* a1, GUID* a2, __int64* a3) {
    int ret=pOriginalQueryApiImpl(a1, a2, a3);
    if(XStoreAPI.matches(a1)){
		//printf("Matched XStoreAPI GUIDs in QueryApiImpl\n");
        XStoreAPI.performAction(*a3);
	}
	return ret;
}
// Initialize hook
BOOL InitializeHook() {
    
    // Get handle to xgameruntime.dll
    HMODULE hModule = GetModuleHandleA("xgameruntime.dll");
    if (hModule == nullptr) {
        return FALSE;
    }

    // Get address of QueryApiImpl
    FARPROC pQueryApiImpl = GetProcAddress(hModule, "QueryApiImpl");
    if (pQueryApiImpl == nullptr) {
        return FALSE;
    }

    // Initialize MinHook
    if (MH_Initialize() != MH_OK) {
        return FALSE;
    }

    // Create hook
    if (MH_CreateHook(pQueryApiImpl, &HookedQueryApiImpl,
        reinterpret_cast<LPVOID*>(&pOriginalQueryApiImpl)) != MH_OK) {
        MH_Uninitialize();
        return FALSE;
    }

    // Enable hook
    if (MH_EnableHook(pQueryApiImpl) != MH_OK) {
        MH_Uninitialize();
        return FALSE;
    }

    return TRUE;
}

// Cleanup hook
void CleanupHook() {
    MH_DisableHook(MH_ALL_HOOKS);
    MH_Uninitialize();
}

// Thread function to wait for xgameruntime.dll to load
DWORD WINAPI WaitForModuleThread(LPVOID lpParam) {

    const int MAX_ATTEMPTS = 300; // 30 seconds (300 * 100ms)
    int attempts = 0;

    while (attempts < MAX_ATTEMPTS) {
        HMODULE hModule = GetModuleHandleA("xgameruntime.dll");
        if (hModule != nullptr) {
            // Small delay to ensure the module is fully initialized
            Sleep(500);

            InitializeHook();
            return 0;
        }

        Sleep(100); // Wait 100ms before checking again
        attempts++;
    }
    return 1;
}

BOOL APIENTRY DllMain(HMODULE hModule, DWORD ul_reason_for_call, LPVOID lpReserved) {
    switch (ul_reason_for_call) {
    case DLL_PROCESS_ATTACH:
        // Disable thread notifications for efficiency
        DisableThreadLibraryCalls(hModule);
        // Redirect stdout and stderr to the console
        initXStoreAPISet();
        // Try to initialize the hook immediately
        if (!InitializeHook()) {
            // Create a thread to wait for the module to load
            HANDLE hThread = CreateThread(
                nullptr,                // Default security attributes
                0,                      // Default stack size
                WaitForModuleThread,    // Thread function
                nullptr,                // No parameter
                0,                      // Start immediately
                nullptr                 // Don't need thread ID
            );
            if (hThread != nullptr) {
                // Close handle as we don't need to wait for it
                CloseHandle(hThread);
            }
        }

        break;

    case DLL_PROCESS_DETACH:
        CleanupHook();
        FreeConsole();
        break;

    case DLL_THREAD_ATTACH:
    case DLL_THREAD_DETACH:
        break;
    }

    return TRUE;
}
